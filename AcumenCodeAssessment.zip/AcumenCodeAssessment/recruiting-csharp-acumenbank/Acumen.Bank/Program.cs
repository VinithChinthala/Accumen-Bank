﻿using System;
using System.Threading;
using Acumen.Bank.Account;

namespace Acumen.Bank
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Acumen Bank!");
		    Console.WriteLine();

		    CheckingAccount michaelsAccount = new CheckingAccount("Michael", 5000);
		    CheckingAccount gobsAccount = new CheckingAccount("Gob", 2000);

		    Console.WriteLine("Open Accounts:");
		    Console.WriteLine();
		    PrintAccountDetails(michaelsAccount);
		    Console.WriteLine();
		    PrintAccountDetails(gobsAccount);

		    Console.WriteLine();
		    Console.WriteLine("Making transfer of $1000.00...");
            try
            {
                Thread.Sleep(500);
            }
            catch (ThreadInterruptedException)
            {
                return;
            }

		    michaelsAccount.Transfer(gobsAccount,michaelsAccount, 1000);
            

		    Console.WriteLine("Updated Account Details:");
		    Console.WriteLine();
		    PrintAccountDetails(michaelsAccount);
		    Console.WriteLine();
		    PrintAccountDetails(gobsAccount);


            // sample code for savings account implementation
            
            // Initialize new savings account with initial balance of $30,000 and 0.89% interest
              SavingsAccount acesSavingsAccount = new SavingsAccount("Ace", 1500,0.043);
              
              SavingsAccount garysSavingsAccount = new SavingsAccount("Gary", 10000, 0.056);
            Console.WriteLine("Open Savings Accounts:");
            Console.WriteLine();
            PrintSavingAccountDetails(acesSavingsAccount);
            Console.WriteLine();
            PrintSavingAccountDetails(garysSavingsAccount);

            Console.WriteLine();
            //Console.WriteLine("Making transfer of $5000.00...");
            try
            {
                Thread.Sleep(500);
            }
            catch (ThreadInterruptedException)
            {
                return;
            }
            // apply 2 years of interest to the savings accounts
            
            Console.WriteLine("Calcuating Compound Interest for Ace's Savings Accounts for 6 years, compounded once annually");
            acesSavingsAccount.applyInterest(1, 6);
            Console.WriteLine("Interest: {0:C2}\r\n", acesSavingsAccount.applyInterest(1, 6));
            Console.WriteLine("Calcuating Compound Interest for Gary's Savings Accounts for 2 years, compounded twice annually");
            garysSavingsAccount.applyInterest(2, 2);
            Console.WriteLine("Interest: {0:C2}\r\n", garysSavingsAccount.applyInterest(2, 2));
            Console.WriteLine("Making transfer of $1000.00...");
            acesSavingsAccount.Transfer(garysSavingsAccount, acesSavingsAccount, 1000);
            Console.WriteLine("Updated Account Details:");
            Console.WriteLine();
            PrintSavingAccountDetails(acesSavingsAccount);
            Console.WriteLine();
            PrintSavingAccountDetails(garysSavingsAccount);
            Console.ReadLine();
        }

	    private static void PrintAccountDetails(CheckingAccount account) {
		    Console.WriteLine("Account for {0}:\r\n", account.OwnerName);
            Console.WriteLine("Balance: {0:C2}\r\n", account.Balance);
	    }
        private static void PrintSavingAccountDetails(SavingsAccount account)
        {
            Console.WriteLine("Account for {0}:\r\n", account.OwnerName);
            Console.WriteLine("Balance: {0:C2}\r\n", account.Principal);
            Console.WriteLine("Rate Of Interest: {0}%\r\n", account.RateOfInterest*100);

        }
    }
}
