﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acumen.Bank.Account
{
    public class SavingsAccount
    {
        public string OwnerName { get; private set; }
        public double Principal { get; private set; }
        public double RateOfInterest { get; private set; }

        public SavingsAccount(string ownerName, double principal, double rateOfInterest)
        {
            this.OwnerName = ownerName;
            this.Principal = principal;
            this.RateOfInterest = rateOfInterest;
        }

        public void Deposit(double amount)
        {
            if (amount < 0)
            {
                throw new ArgumentException("Cannot deposit a negative amount");
            }
            this.Principal += amount;
        }

        private void Withdraw(double amount)
        {
            if (amount < 0)
            {
                throw new ArgumentException("Cannot withdraw a negative amount");
            }
            this.Principal -= amount;
        }

        public void Transfer(SavingsAccount destinationAccount, SavingsAccount sourceAccount, double amount)
        {
            destinationAccount.Deposit(amount);
            sourceAccount.Withdraw(amount);
        }

        public double applyInterest(int numberOfTimes, int numberOfYears)
        {
            double compoundedInterest = 0;
            double compoundedPrincipal = Principal * Math.Pow((1+(RateOfInterest/numberOfTimes)),(numberOfYears*numberOfTimes));
            return compoundedPrincipal;//compoundedInterest=compoundedPrincipal-Principal;
        }
    }
}
